#include <iostream>
#include <fstream>
#include <string>
#include "Course.h"
#include "Date.h"
#include "AttendanceRecord.h"

using namespace std;

Course::Course(string id, string title, Date startTime, Date endTime) :
    id(id), title(title), startTime(startTime), endTime(endTime) {}
string Course::getID() {
    return id;
}
string Course::getTitle() {
    return title;
}
Date Course::getStartTime() {
    return startTime;
}
Date Course::getEndTime() {
    return endTime;
}
void Course::addAttendanceRecord(AttendanceRecord ar) {
    attendanceRecords.push_back(ar);
}
void Course::outputAttendance() {
    for (int i = 0; i < attendanceRecords.size(); i++) {
        Date a = attendanceRecords[i].getDate();
        string date = a.getDateTime();
        cout << date << ',' << attendanceRecords[i].getCourseID() << ',' << attendanceRecords[i].getStudentID() << '\n';
    }
}
void Course::outputAttendance(string student_id) {
    int count = 0;
    for (int i = 0; i < attendanceRecords.size(); i++) {
        Date a = attendanceRecords[i].getDate();
        string date = a.getDateTime();
        if (attendanceRecords[i].getStudentID() == student_id) {
            cout << date << ',' << attendanceRecords[i].getCourseID() << ',' << attendanceRecords[i].getStudentID() << '\n';
            ++count;
        }
    }
    if (count == 0) {
        cout << "No Records\n";
    }
}
