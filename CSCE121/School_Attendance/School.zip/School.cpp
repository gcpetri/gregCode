#include <iostream>
#include <sstream>
#include <fstream>
#include <string>
#include <iomanip>
#include "School.h"
#include "AttendanceRecord.h"

using namespace std;

// students
void School::addStudents(string filename) {
  ifstream ifs(filename);
  if (!ifs.is_open()) {
    cout << "Unable to open file: " << filename << endl;
    return;
  }
  while (!ifs.eof()) {
    string line;
    getline(ifs, line);
    istringstream ss(line);
    string uin;
    getline(ss, uin, ',');
    string name;
    getline(ss, name);
    int check = 0;
    int len = students.size();
    for (int i = 0; i < len; i++) {
      if (uin == students[i].get_id()) {
        ++check;
      }
    }
    if (!ss.fail() && check == 0) {
      students.push_back(Student(uin, name));
    }
  }
}
void School::listStudents() {
    if (!students.empty()) {
      int len = students.size();
      for (int i = 0; i < len; i++) {
        cout << students[i].get_id() << ',';
        cout << students[i].get_name() << '\n';
      }
    } 
    else {
      cout << "No Students\n";
    }
}
// courses
void School::addCourses(string filename) {
  ifstream ifs(filename);
  if (!ifs.is_open()) {
    cout << "Unable to open file: " << filename << endl;
    return;
  }
  while (!ifs.eof()) {
    string line;
    getline(ifs, line);
    istringstream ss(line);
    string courseid;
    getline(ss, courseid, ',');
    string starthour;
    getline(ss, starthour, ':');
    string startmin;
    getline(ss, startmin, ',');
    string endhour;
    getline(ss, endhour, ':');
    string endmin;
    getline(ss, endmin, ',');
    string title;
    getline(ss, title);
    int check = 0;
    int len = courses.size();
    for (int i = 0; i < len; i++) {
      if (courseid == courses[i].getID()) {
        ++check;
      }
    }
    if (!ss.fail() && check == 0) {
      int sthr = stoi(starthour);
      int stmin = stoi(startmin);
      int edhour = stoi(endhour);
      int edmin = stoi(endmin);
      courses.push_back(Course(courseid, title, Date(sthr, stmin), Date(edhour, edmin)));
    }
  }
}
void School::listCourses() {
    if (!courses.empty()) {
      int len = courses.size();
      for (int i = 0; i < len; i++) {
        cout << courses[i].getID() << ',';
        Date a = courses[i].getStartTime();
        Date b = courses[i].getEndTime();
        cout << a.getTime(false) << ',';
        cout << b.getTime(false) << ',';
        cout << courses[i].getTitle() << '\n';
      }
    } else {
      cout << "No Courses\n";
    }
}
// get attendance
void School::addAttendanceData(string filename) {
  ifstream ifs(filename);
  if (!ifs.is_open()) {
    cout << "Unable to open file: " << filename << endl;
    return;
  }
  while (!ifs.eof()) {
    string line;
    getline(ifs, line);
    istringstream ss(line);
    string year;
    getline(ss, year, '-');
    string month;
    getline(ss, month, '-');
    string day;
    getline(ss, day, ' ');
    string hour;
    getline(ss, hour, ':');
    string minute;
    getline(ss, minute, ':');
    string second;
    getline(ss, second, ',');
    string courseid;
    getline(ss, courseid, ',');
    string studentid;
    getline(ss, studentid);

    if (!ifs.fail()) {
      int yr = stoi(year);
      int mth = stoi(month);
      int dy = stoi(day);
      int hr = stoi(hour);
      int min = stoi(minute);
      int sec = stoi(second);
      for (int i = 0; i < courses.size(); i++) {
        if(courses[i].getID() == courseid) {
          Date starttime = courses[i].getStartTime();
          Date endtime = courses[i].getEndTime();
          if (starttime.operator<=(Date(hr, min, sec)) && endtime.operator>=(Date(hr, min, sec))) {
            courses[i].addAttendanceRecord(AttendanceRecord(courseid, studentid, Date(yr, mth, dy, hr, min, sec)));
          } else {
            cout << "did not save this record.\n";
          }
          break;
        }
      }   
    }
  }
}
// output attendance for specific course
void School::outputCourseAttendance(string course_id) {
  for (int i = 0; i < courses.size(); i++) {
    if (courses[i].getID() == course_id) {
      courses[i].outputAttendance();
    }
  }
}
// output attendance for specific student & specific course
void School::outputStudentAttendance(string student_id, string course_id) {
  for (int i = 0; i < courses.size(); i++) {
    if (courses[i].getID() == course_id) {
      courses[i].outputAttendance(student_id);
    }
  }
}