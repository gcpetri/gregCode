#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include "Student.h"

using namespace std;

Student::Student(string student_id, string name) :
    id(student_id), name(name) {}

string Student::get_id() {
    return this->id;
}
string Student::get_name() {
    return this->name;
}
void Student::addCourse(string course_id) {
    course_ids.push_back(course_id);
}
void Student::listCourses() {
    int len = course_ids.size();
    for (int i = 0; i < len; i++) {
        cout << course_ids[i] << '\n';
    }
}
